﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class Name_NPM : MonoBehaviour
{
    public GameObject nama,npm;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void appearNama(){
        if(nama != null){
            bool isActive = nama.activeSelf;
            nama.SetActive(!isActive);
        }
      
    }
     public void appearNpm(){
         if(npm != null){
            bool isActive = npm.activeSelf;
            npm.SetActive(!isActive);
        }
    }
}
