﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class movement : MonoBehaviour
{
Rigidbody2D rigidb;
public float jump;
float score;
public Text scorePlayer;

    void Start()
    {
        rigidb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        if(Time.timeScale == 0 && Input.GetMouseButtonDown(0) ){
            Time.timeScale = 1;

        }
        scorePlayer.text = "Score: " + score; 
        if(Input.GetMouseButtonDown(0)){
            rigidb.velocity = Vector2.up * jump;    
        }
    }
    private void OnTriggerEnter2D(Collider2D collision){
        if(collision.gameObject.tag== "score"){
            score++;
        }
        if(collision.gameObject.tag == "pipa"){
            Time.timeScale = 0;
            Destroy(gameObject);
        }
        if(collision.gameObject.tag == "dropPlayer"){
          rigidb.velocity = Vector2.down * 100;  
       
        }
    }
}
