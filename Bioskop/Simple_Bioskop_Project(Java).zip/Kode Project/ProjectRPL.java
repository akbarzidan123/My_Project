import java.util.*;
/**
* @author: Akbar Zidan Al Zakki (1402018067)
*			
*
*/
public class ProjectRPL{
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("-----------------------------------------");
		System.out.println("      Selamat Datang Di BiosScope       ");
		System.out.println("-----------------------------------------");
		String a = "11000123";
		System.out.println(a.matches(".*[2-9]+"));
		FilmBioskop film = new FilmBioskop(in);
		
	}
}